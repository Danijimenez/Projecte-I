#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleHallOfAces.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include "ModuleWelcome.h"
#include "ModulePlayer.h"
#include "ModuleAudio.h"


// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModuleHallOfAces::ModuleHallOfAces()
{
	HallOfAces = { 0, 0, 358, 481 };
}

ModuleHallOfAces::~ModuleHallOfAces()
{}

// Load assets
bool ModuleHallOfAces::Start()
{
	LOG("Loading Hall of Aces scene");
	App->stop_music = true;
	graphics = App->textures->Load("hall_of_aces.png");
	App->audio->Play("hall_of_aces.ogg");
	App->render->camera.x = -25;
	App->render->camera.y = 0;
	return true;
}

// UnLoad assets
bool ModuleHallOfAces::CleanUp()
{
	LOG("Unloading Hall of Aces scene");

	App->textures->Unload(graphics);
	if (App->stop_music) {
		App->audio->Stop();
	}
	gate_aces = true;


	return true;
}

// Update: draw background
update_status ModuleHallOfAces::Update()
{


	// Draw everything --------------------------------------
	App->render->Blit(graphics, 0, 0, &HallOfAces);


	if (App->input->keyboard[SDL_SCANCODE_SPACE] && gate_aces) {
		App->fade->FadeToBlack(this, App->welcome, 2.0f);
		gate_aces = false;

	}
	return UPDATE_CONTINUE;
}
