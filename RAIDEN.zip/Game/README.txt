
RAIDEN 

Controls

Press SPACE to start.
	-Press 1 to play as player 1
	-Press 2 to play as player 2
	-Press 3 to play as both players (coop)

Move player 1 with W,A,S,D.
Move player 2 with I,J,K,L.

Player 1 shoot with Left CONTROL.
Player 2 shoot with Right CONTRL.

Press ESCAPE to exit the game.

F1 to activate/desactivate DebugDraw.




//**New**\\

Player 2 and enemies


Colliders (player and enemy)
Camera limits



Added player animation and movement.
Added player shoot (and sound).
Fixed memory leaks.
Fixed Mix_Quit(); memory violation acces.
