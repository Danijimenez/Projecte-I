
RAIDEN 

Raiden is a scrolling shoot'em up arcade game where you controls a ship and kills other ships or aliens.
The objective is to destroy all the enemies you see and pass all the levels of the game.
This kind of games are trully difficult and frenetic because there are thousands of enemies and projectiles
that you need to avoid, but it's very addictive.

Plot: In the year 2090, the Earth is being attacked by aliens known as the Cranassians.
During the invasion, the World Alliance Military is building a new aircraft based on a 
captured alien craft, the Raiden Supersonic Attack Fighter.

Controls

To Start:
	-Press 1 to play as player 1.
	-Press 2 to play as player 2.
	-Press 3 to play as both players (coop).

Move player 1 with W,A,S,D.
Move player 2 with arrows.

Player 1 shoot with SPACE BAR.
Player 2 shoot with Right CONTRL.

Press ESCAPE to exit the game.

F1 Welcome Screen.
F2 to activate/desactivate Colliders.
F3 to activate/desactivate God Mode Player 1.
F4 to activate/desactivate God Mode Player 2.
F5 to activate/desactivate Debug Screen.
F6 to Win/Lose Screen.

Debug Screen controls:
	-Press 1 to spawn player 1
	-Press 2 to spawn player 2
	-Press 3 to spawn a Basic Enemy
	-Press 4 to spawn a Green Ship
	-Press 5 to spawn a Turret
	-press 6 to spawn a Power Up Ship
	-Press 7 to spawn a PowerUp
	-Press "o" to activate laser PowerUp
	-Press "p" to activate vulcan PowerUp
	

V0.5:
-Added Win/Lose condition.
-Sound effects implemented.
-Debug funcionality: God Mode,Collision Boxes.
-Added Score.
-Second Player implemented.
-3 types of enemies implemented.
-2 power ups implemented.

V0.4:
-Added camera limits to the player.
-Added colliders to the player and its particles.
-Player can collide with the enviroment, enemies...


V0.3:
-Player moving without collisions.
-Player animated.
-Added background animation.
-Added a particle and fx to the player shot.

V0.2:
-Welcome Screen.
-First Level.
-Second Level.
-Congrats Screen.
-Added music to each screen.

V0.1:
-Background that scrolls.
-Added an Audio Module.


#Members of the Group:#

	Manel Mourelo Montero

		GitHub account: https://github.com/manelmourelo

		Responsibility: Quality Assurance.

	Oscar Hern�ndez G�mez

		GitHub account: https://github.com/OscarHernandezG

		Responsibility: Code.
	
	Victor Agrisuelas Pascual

		GitHub account: https://github.com/victoragri98

		Responsibility: Design.

	Daniel Jim�nez Kaddour

		GitHub account: https://github.com/Danijimenez

		Responsibility: Management.




